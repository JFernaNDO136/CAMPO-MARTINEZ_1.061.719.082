DROP DATABASE IF EXISTS empresa;
CREATE DATABASE empresa;
USE empresa;
CREATE TABLE Cliente (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre_completo VARCHAR(200) NOT NULL,
    direccion VARCHAR(100),
    fecha_nacimiento DATE,
    telefono VARCHAR(150)
);
CREATE TABLE Proveedor (
    id_Proveedor INT PRIMARY KEY AUTO_INCREMENT,
    nombre_cliente VARCHAR(200),
    nombre_Producto VARCHAR(200),
    cargo VARCHAR(100)
);
CREATE TABLE Producto (
    id_Producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre_producto VARCHAR(200),
    precio VARCHAR(100)
);