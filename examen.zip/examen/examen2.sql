INSERT INTO Cliente ( id , nombre_completo, direccion, fecha_nacimiento, telefono ) VALUES
( '1234567890', 'María González', 'calle 5 # 22-18', '10/05/2007', '3215971370'),
( '1234567891', 'Felipe Sarate', 'calle 4 # 20-11', '10/05/2007', '3215971371'),
( '1234567892', 'Juan Valencia', 'calle 3 # 28-17', '10/05/2007', '3215971372'),
( '1234567893', 'Dominik Salazar', 'calle 2 # 21-10', '10/05/2007', '3215971373'),
( '1234567894', 'Juliana Pame', 'calle 10 # 22-15', '10/05/2007', '3215971374'),
( '1234567895', 'Miguel Gomez', 'calle 18 # 27-14', '10/05/2007', '3215971375'),
( '1234567896', 'Sebastian Ordoñez', 'calle 30 # 25-14', '10/05/2007', '3215971376'),
( '1234567897', 'Pablo Mejia', 'calle 12 # 25-16', '10/05/2007', '3215971377');

INSERT INTO Proveedor ( id , nombre_completo, producto, cargo ) VALUES
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente'),
( '1234567896', 'Sebastian Ordoñez', 'computador', 'cliente');
